XTREME.NET — Free starter

WHAT THIS IS
A static homepage demo. Search and category filters work. The upload picker is only a local preview.
It does NOT yet provide public accounts, real uploads, comments, likes, moderation, or video storage.

FREE DEPLOYMENT (Cloudflare Pages)
1. Create a GitHub account at https://github.com/ if you do not have one.
2. Create a new public repository named xtreme-net.
3. Upload index.html to the repository root.
4. Create a free Cloudflare account at https://dash.cloudflare.com/
5. Open Workers & Pages -> Create -> Pages -> Connect to Git.
6. Select your xtreme-net repository. For a plain HTML site, choose no framework;
   build command can be left blank and output directory set to / (root) if requested.
7. Deploy. Cloudflare will provide a free address such as project-name.pages.dev.

IMPORTANT
A free static host can publish the website, but it cannot by itself power public video uploads.
For the next stage we need authentication, a database, secure upload rules, video storage/transcoding,
moderation/reporting, and bandwidth limits. Free tiers have quotas and may not support a large public
video platform. Do not put passwords, secret keys, or payment details in public source files.
